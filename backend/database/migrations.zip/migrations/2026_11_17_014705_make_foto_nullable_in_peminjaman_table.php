<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // kolom sekarang bukan json, jadi tipenya diubah dengan USING;
        // nilai null/kosong diisi array kosong supaya aman untuk SET NOT NULL
        DB::statement(<<<'SQL'
            ALTER TABLE peminjaman
                ALTER COLUMN foto TYPE json USING COALESCE(NULLIF(foto, ''), '[]')::json,
                ALTER COLUMN foto SET DEFAULT '[]'::json,
                ALTER COLUMN foto SET NOT NULL
        SQL);
    }
    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('peminjaman', function (Blueprint $table) {
            //
        });
    }
};
